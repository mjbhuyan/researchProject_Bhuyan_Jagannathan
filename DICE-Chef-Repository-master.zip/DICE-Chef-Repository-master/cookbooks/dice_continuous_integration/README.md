# DICE Continuous Integration Cookbook

This cookbook contains recipes for setting up the DICE Continuous Integration.
It consists of the Jenkins Continuous Integration and a Jenkins plug-in.

### Platforms

- Ubuntu 14.04

### Chef

- Chef 12.0 or later

### Cookbooks

