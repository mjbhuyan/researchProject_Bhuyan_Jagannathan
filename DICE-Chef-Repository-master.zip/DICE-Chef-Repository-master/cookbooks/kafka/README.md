# Apache Kafka cookbook

This cookbook installs and configures Apache Kafka broker(s).

> NOTE: This cookbook is meant to be used in conjunction with Cloudify and
> DICE TOSCA library.
