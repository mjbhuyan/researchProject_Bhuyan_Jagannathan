name 'kafka'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'Apache 2.0'
description 'Install and configure Apache Kafka broker'
version '0.1.0'

depends 'poise-archive'
