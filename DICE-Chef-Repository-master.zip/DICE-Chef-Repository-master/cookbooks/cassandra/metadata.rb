name 'cassandra'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'Apache 2.0'
description 'Configure and start Apache Cassandra'
version '0.1.1'

depends 'poise-archive'
depends 'dice_common'
