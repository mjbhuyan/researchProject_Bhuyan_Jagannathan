name 'scylla'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'Apache 2.0'
description 'Configure and start ScyllaDB'
version '0.1.0'

depends 'yum'
