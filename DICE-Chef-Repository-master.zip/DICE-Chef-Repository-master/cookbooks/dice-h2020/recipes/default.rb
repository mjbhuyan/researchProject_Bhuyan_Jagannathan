#
# Cookbook Name:: dice-h2020
# Recipe:: default
#
# Copyright 2016, XLAB d.o.o.
#
# Apache 2 license
#
