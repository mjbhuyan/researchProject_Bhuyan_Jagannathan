name 'mongodb'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'apachev2'
description 'Installs/Configures mongodb'
long_description 'Installs/Configures mongodb'
version '0.1.0'

depends 'dice_common'
