# MongoDB

Cookbook for setting up MongoDB cluster.
