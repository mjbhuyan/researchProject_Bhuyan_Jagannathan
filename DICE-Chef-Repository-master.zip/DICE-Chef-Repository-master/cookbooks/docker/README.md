# Docker cookbook

Simple cookbook that can be used to install simple docker server.
