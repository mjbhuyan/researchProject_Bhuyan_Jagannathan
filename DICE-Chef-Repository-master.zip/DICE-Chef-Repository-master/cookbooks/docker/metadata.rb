name 'docker'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'Apache-2.0'
description 'Installs/Configures docker'
long_description 'Installs/Configures docker'
version '0.1.0'

depends 'dice_common'
