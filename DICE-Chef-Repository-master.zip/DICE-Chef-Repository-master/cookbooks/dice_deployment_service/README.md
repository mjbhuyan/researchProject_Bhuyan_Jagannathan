# DICE Deployment Service cookbook

This cookbook should be used to setup DICE deployment service. By simply
running default recipe, deployment service should be up and running. Adding
consul server completes the installation.


## Example usage

For sample usage, see `.kitchen.yml` file that lists all of the recipes that
are needed during normal setup.


## Attributes

Quite a few attributes are supplied by Cloudify. For description, consult
default attributes file.
