# Apache Spark Cookbook

This cookbook contains recipes for setting up standalone Apache Spark cluster.


## Notes

This cookbook is meant to be used in conjunction with Cloudify, which means
that some of the attributes are dynamically supplied by Cloudify before Chef
is being run. List of required attributes can be seen in `.kitchen.yml` file.
