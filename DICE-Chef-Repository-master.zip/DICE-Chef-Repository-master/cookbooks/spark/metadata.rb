name 'spark'
maintainer 'XLAB d.o.o.'
maintainer_email 'tadej.borovsak@xlab.si'
license 'Apache 2.0'
description 'Installs/Configures spark'
version '0.1.1'

depends 'poise-archive'
