# Apache Hadoop Cookbook

This cookbook installs and configures Apache Hadoop cluster.

> NOTE: This cookbook is meant to be used in conjunction with Cloudify and
> DICE TOSCA library.
